/* ISC license. */

#ifndef ENVIRON_H
#define ENVIRON_H

extern char **environ ;

#endif

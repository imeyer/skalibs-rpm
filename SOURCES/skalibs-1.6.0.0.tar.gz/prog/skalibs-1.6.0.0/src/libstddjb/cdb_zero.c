/* ISC license. */

#include "cdb.h"

struct cdb const cdb_zero = CDB_ZERO ;

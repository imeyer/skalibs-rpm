/* ISC license. */

#include "uint16.h"
#include "fmtscan-internal.h"

FMTL(32)

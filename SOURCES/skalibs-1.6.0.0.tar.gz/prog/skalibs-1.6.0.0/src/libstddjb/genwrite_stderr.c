/* ISC license. */

#include "buffer.h"
#include "genwrite.h"

genwrite_t genwrite_stderr = GENWRITE_BUFFER_INIT(buffer_2) ;

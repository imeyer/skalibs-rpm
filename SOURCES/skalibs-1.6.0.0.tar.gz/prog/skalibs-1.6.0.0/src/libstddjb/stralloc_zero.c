/* ISC license. */

#include "stralloc.h"

stralloc const stralloc_zero = STRALLOC_ZERO ;

/* ISC license. */

#include "tai.h"

struct taia const taia_nano500 = TAIA_NANO500 ;

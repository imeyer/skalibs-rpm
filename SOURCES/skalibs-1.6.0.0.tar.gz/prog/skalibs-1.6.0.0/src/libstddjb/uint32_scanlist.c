/* ISC license. */

#include "uint16.h"
#include "fmtscan-internal.h"

SCANL(32)

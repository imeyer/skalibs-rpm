/* ISC license. */

#include "uint16.h"
#include "fmtscan-internal.h"

SCANB(16)

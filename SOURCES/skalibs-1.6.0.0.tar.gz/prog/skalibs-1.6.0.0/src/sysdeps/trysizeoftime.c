#include <sys/types.h>
#include <stdio.h>

int main (void)
{
  printf("%u\n", sizeof(time_t)) ;
  return 0 ;
}

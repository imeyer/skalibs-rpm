#include <sys/types.h>
#include <stdio.h>

int main (void)
{
  printf("%u\n", sizeof(gid_t)) ;
  return 0 ;
}

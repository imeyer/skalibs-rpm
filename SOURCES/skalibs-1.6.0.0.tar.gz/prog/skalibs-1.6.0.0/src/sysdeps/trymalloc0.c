/* ISC license */

#include <stdlib.h>
int main() { return !malloc(0) ; }

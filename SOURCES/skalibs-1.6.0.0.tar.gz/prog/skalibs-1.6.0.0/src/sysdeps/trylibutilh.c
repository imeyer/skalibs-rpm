/* ISC license. */

#include <sys/types.h>
#include <libutil.h>
static char dummy = 0 ;

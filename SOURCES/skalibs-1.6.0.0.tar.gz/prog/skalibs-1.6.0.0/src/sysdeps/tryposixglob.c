/* ISC license. */

#include <glob.h>

static int dummy[2] = { GLOB_NOMATCH, GLOB_NOESCAPE } ;

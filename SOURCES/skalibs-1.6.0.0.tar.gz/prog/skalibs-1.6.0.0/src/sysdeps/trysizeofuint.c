#include <stdio.h>

int main (void)
{
  printf("%u\n", sizeof(unsigned int)) ;
  return 0 ;
}

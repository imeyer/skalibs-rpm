/* ISC license. */

#include <sys/types.h>
#include <pty.h>
static char dummy = 0 ;

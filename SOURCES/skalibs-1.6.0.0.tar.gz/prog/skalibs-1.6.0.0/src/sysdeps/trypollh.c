/* ISC license. */

#include <sys/types.h>
#include <poll.h>
static char dummy = 0 ;
